package com.guicopy.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;

import java.util.List;

public class GuiCopyCommand {

    public static void execute(MinecraftClient client, GuiCopyConfig config) {
        executeWithRadius(client, config, config.searchRadius);
    }

    public static void executeWithRadius(MinecraftClient client, GuiCopyConfig config, int radius) {
        if (client.player == null || client.world == null) return;

        // Find hologram groups nearby
        List<List<ArmorStandEntity>> groups = HologramFinder.findGroups(client, radius);

        if (groups.isEmpty()) {
            client.player.sendMessage(Text.literal(
                "§c[GuiCopy] No hologram found within §e" + radius + " §cblocks!"), false);
            return;
        }

        // Use the nearest group
        List<ArmorStandEntity> nearestGroup = groups.get(0);
        List<String> lines = HologramFinder.extractLines(nearestGroup);

        if (lines.isEmpty()) {
            client.player.sendMessage(Text.literal(
                "§c[GuiCopy] Found an ArmorStand but it has no text!"), false);
            return;
        }

        // Show preview in chat
        client.player.sendMessage(Text.literal("§7§m-----------------------------"), false);
        client.player.sendMessage(Text.literal("§b§lHologram Preview:"), false);
        for (String line : lines) {
            client.player.sendMessage(Text.literal("§7» §f" + line), false);
        }
        client.player.sendMessage(Text.literal("§7§m-----------------------------"), false);

        // Send to Discord
        DiscordWebhook.send(client, config, nearestGroup, lines);
    }
}
