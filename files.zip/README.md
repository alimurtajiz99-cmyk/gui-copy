# GuiCopy — Fabric Mod

A **client-side Fabric mod** for Minecraft 1.21.4 that lets you copy nearby ArmorStand holograms and send them to Discord via a webhook with a fancy embed.

---

## 📦 Requirements

- Minecraft **1.21.4**
- [Fabric Loader](https://fabricmc.net/use/installer/) **0.16.9+**
- [Fabric API](https://modrinth.com/mod/fabric-api) **0.119.0+1.21.4**
- Java **21+**

---

## 🚀 Installation

1. Install [Fabric Loader](https://fabricmc.net/use/installer/)
2. Download [Fabric API](https://modrinth.com/mod/fabric-api) and put it in `.minecraft/mods/`
3. Drop `guicopy-1.0.0.jar` into `.minecraft/mods/`
4. Launch Minecraft once — a config file will be created at:
   `.minecraft/config/guicopy.json`
5. Edit the config and add your Discord webhook URL

---

## ⚙️ Configuration

Located at `.minecraft/config/guicopy.json`:

```json
{
  "webhookUrl": "https://discord.com/api/webhooks/YOUR_ID/YOUR_TOKEN",
  "serverIp": "play.yourserver.net",
  "searchRadius": 5,
  "embedColor": 5814783,
  "embedFooter": "GuiCopy • Hologram Copied"
}
```

### How to get a Discord Webhook URL
1. Open Discord → go to the channel you want
2. ⚙️ Edit Channel → **Integrations** → **Webhooks**
3. Click **New Webhook** → copy the URL
4. Paste it as `webhookUrl` in `guicopy.json`

---

## 🕹️ Commands

| Command | Description |
|---|---|
| `/guicopy` | Copy nearest hologram (uses config radius) |
| `/guicopy <radius>` | Copy nearest hologram within custom radius (1–50) |
| `/guicopyreload` | Reload `guicopy.json` config without restarting |

---

## 📋 What Gets Sent to Discord

The embed includes:

| Field | Info |
|---|---|
| 👤 Copied By | Your Minecraft username |
| 📍 Location | X / Y / Z + dimension |
| 🖥️ Server | Server name from multiplayer list |
| 🌐 Server IP | Server address |
| 👥 Players Online | Current tab-list player count |
| 📝 Lines | Number of hologram lines |
| 📜 Hologram Content | All lines in a code block |

---

## 🏗️ Building from Source

```bash
./gradlew build
```

Output jar: `build/libs/guicopy-1.0.0.jar`

Requires **Java 17** and an internet connection to download Fabric dependencies.

---

## ✅ Compatibility

- Works with **HolographicDisplays**, **DecentHolograms**, **CMI**, and any plugin using ArmorStand-based holograms
- Client-side only — works on any server, no server-side install needed
