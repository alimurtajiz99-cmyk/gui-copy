package com.guicopy.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class DiscordWebhook {

    /**
     * Sends hologram content + server info to Discord as a fancy embed.
     */
    public static void send(MinecraftClient client, GuiCopyConfig config,
                            List<ArmorStandEntity> group, List<String> lines) {

        if (client.player == null) return;

        String webhookUrl = config.webhookUrl;
        if (webhookUrl.isEmpty() || webhookUrl.contains("YOUR_WEBHOOK")) {
            client.player.sendMessage(Text.literal(
                "§c[GuiCopy] Webhook URL not set! Edit §e.minecraft/config/guicopy.json"), false);
            return;
        }

        // ── Hologram content ──────────────────────────────────────────────
        StringBuilder sb = new StringBuilder();
        for (String line : lines) sb.append(line).append("\\n");
        String hologramBlock = lines.isEmpty()
                ? "*(empty)*"
                : "```\\n" + sb.toString().stripTrailing() + "\\n```";

        // ── Location ──────────────────────────────────────────────────────
        ArmorStandEntity first = group.get(0);
        String location = String.format("X: %.1f | Y: %.1f | Z: %.1f\\nWorld: **%s**",
                first.getX(), first.getY(), first.getZ(),
                client.world != null ? client.world.getRegistryKey().getValue().getPath() : "unknown");

        // ── Server info ───────────────────────────────────────────────────
        ServerInfo serverInfo = client.getCurrentServerEntry();
        String serverName = serverInfo != null ? serverInfo.name : "Singleplayer";
        String serverIp   = serverInfo != null ? serverInfo.address : config.serverIp;

        // Player count from client-side tab list
        int onlinePlayers = client.getNetworkHandler() != null
                ? client.getNetworkHandler().getListedPlayerListEntries().size() : 1;

        String playerName = client.player.getName().getString();
        String timestamp  = Instant.now().toString();

        // ── Build JSON ────────────────────────────────────────────────────
        String json = "{"
            + "\"username\":\"GuiCopy\","
            + "\"avatar_url\":\"https://i.imgur.com/4M34hi2.png\","
            + "\"embeds\":[{"
            + "\"title\":\"📋 Hologram Copied\","
            + "\"color\":" + config.embedColor + ","
            + "\"fields\":["
            + field("👤 Copied By",          "**" + esc(playerName) + "**",       true)  + ","
            + field("📍 Location",            esc(location),                        true)  + ","
            + field("🖥️ Server",             "**" + esc(serverName) + "**",        true)  + ","
            + field("🌐 Server IP",           "`"  + esc(serverIp)  + "`",          true)  + ","
            + field("👥 Players Online",      "**" + onlinePlayers + "**",          true)  + ","
            + field("📝 Lines",               "**" + lines.size() + "**",           true)  + ","
            + field("📜 Hologram Content",    hologramBlock,                         false)
            + "],"
            + "\"footer\":{\"text\":\"" + esc(config.embedFooter) + "\"},"
            + "\"timestamp\":\"" + timestamp + "\""
            + "}]}";

        // ── Send async ────────────────────────────────────────────────────
        CompletableFuture.runAsync(() -> {
            try {
                URL url = new URL(webhookUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("User-Agent", "GuiCopyMod/1.0");
                conn.setDoOutput(true);
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                conn.disconnect();

                if (code == 204 || code == 200) {
                    GuiCopyMod.LOGGER.info("Hologram sent to Discord by {}", playerName);
                    client.execute(() -> client.player.sendMessage(
                        Text.literal("§a[GuiCopy] Sent to Discord! §7(" + lines.size() + " lines)"), false));
                } else {
                    GuiCopyMod.LOGGER.warn("Discord webhook returned: {}", code);
                    client.execute(() -> client.player.sendMessage(
                        Text.literal("§c[GuiCopy] Discord returned error code: " + code), false));
                }

            } catch (Exception e) {
                GuiCopyMod.LOGGER.error("Failed to send webhook", e);
                client.execute(() -> client.player.sendMessage(
                    Text.literal("§c[GuiCopy] Failed to send: " + e.getMessage()), false));
            }
        });
    }

    private static String field(String name, String value, boolean inline) {
        return "{\"name\":\"" + esc(name) + "\","
             + "\"value\":\"" + esc(value) + "\","
             + "\"inline\":" + inline + "}";
    }

    private static String esc(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
