package com.guicopy.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GuiCopyMod implements ClientModInitializer {

    public static final String MOD_ID = "guicopy";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static GuiCopyConfig config;

    @Override
    public void onInitializeClient() {
        LOGGER.info("GuiCopy mod loaded! (Minecraft 1.21.4)");

        // Load config
        config = GuiCopyConfig.load();

        // Register /guicopy command
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                ClientCommandManager.literal("guicopy")
                    .executes(ctx -> {
                        GuiCopyCommand.execute(ctx.getSource().getClient(), config);
                        return 1;
                    })
                    .then(ClientCommandManager.argument("radius",
                            com.mojang.brigadier.arguments.IntegerArgumentType.integer(1, 50))
                        .executes(ctx -> {
                            int radius = com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(ctx, "radius");
                            GuiCopyCommand.executeWithRadius(ctx.getSource().getClient(), config, radius);
                            return 1;
                        })
                    )
            );

            // /guicopyreload
            dispatcher.register(
                ClientCommandManager.literal("guicopyreload")
                    .executes(ctx -> {
                        GuiCopyConfig.reload();
                        ctx.getSource().sendFeedback(
                            Text.literal("§aGuiCopy config reloaded!"));
                        return 1;
                    })
            );
        });
    }

    public static GuiCopyConfig getConfig() {
        return config;
    }
}
