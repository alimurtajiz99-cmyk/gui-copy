package com.guicopy.mod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;

public class GuiCopyConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("guicopy.json");

    private static GuiCopyConfig instance;

    // Config fields
    public String webhookUrl   = "https://discord.com/api/webhooks/YOUR_WEBHOOK_ID/YOUR_WEBHOOK_TOKEN";
    public String serverIp     = "play.yourserver.net";
    public int    searchRadius = 5;
    public int    embedColor   = 5814783;
    public String embedFooter  = "GuiCopy • Hologram Copied";

    public static GuiCopyConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                instance = GSON.fromJson(reader, GuiCopyConfig.class);
                GuiCopyMod.LOGGER.info("GuiCopy config loaded.");
                return instance;
            } catch (IOException e) {
                GuiCopyMod.LOGGER.error("Failed to load config, using defaults.", e);
            }
        }
        // Create default config
        instance = new GuiCopyConfig();
        instance.save();
        return instance;
    }

    public static void reload() {
        instance = load();
    }

    public static GuiCopyConfig getInstance() {
        return instance;
    }

    public void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            GuiCopyMod.LOGGER.error("Failed to save config.", e);
        }
    }
}
