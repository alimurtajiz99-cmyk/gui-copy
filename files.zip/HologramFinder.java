package com.guicopy.mod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;

import java.util.*;

public class HologramFinder {

    /**
     * Finds and groups nearby ArmorStand holograms within the given radius.
     * Compatible with Minecraft 1.21.4 (Fabric).
     * Returns groups sorted by distance (closest first).
     * Each group is sorted top-to-bottom by Y position.
     */
    public static List<List<ArmorStandEntity>> findGroups(MinecraftClient client, double radius) {
        if (client.player == null || client.world == null) return Collections.emptyList();

        double px = client.player.getX();
        double py = client.player.getY();
        double pz = client.player.getZ();

        Box searchBox = new Box(px - radius, py - radius, pz - radius,
                                px + radius, py + radius, pz + radius);

        List<ArmorStandEntity> stands = client.world.getEntitiesByClass(
                ArmorStandEntity.class, searchBox,
                as -> as.isInvisible() || as.hasCustomName()
        );

        // Sort all by distance from player
        stands.sort(Comparator.comparingDouble(a -> a.squaredDistanceTo(px, py, pz)));

        // Group by horizontal proximity (same hologram = within 0.5 blocks X/Z)
        List<List<ArmorStandEntity>> groups = new ArrayList<>();
        List<ArmorStandEntity> used = new ArrayList<>();

        for (ArmorStandEntity stand : stands) {
            if (used.contains(stand)) continue;

            List<ArmorStandEntity> group = new ArrayList<>();
            group.add(stand);
            used.add(stand);

            for (ArmorStandEntity other : stands) {
                if (used.contains(other)) continue;
                double dx = Math.abs(stand.getX() - other.getX());
                double dz = Math.abs(stand.getZ() - other.getZ());
                if (dx < 0.5 && dz < 0.5) {
                    group.add(other);
                    used.add(other);
                }
            }

            // Sort top → bottom
            group.sort((a, b) -> Double.compare(b.getY(), a.getY()));
            groups.add(group);
        }

        return groups;
    }

    /**
     * Extracts display text lines from a hologram group.
     */
    public static List<String> extractLines(List<ArmorStandEntity> group) {
        List<String> lines = new ArrayList<>();
        for (ArmorStandEntity stand : group) {
            Text name = stand.getCustomName();
            if (name != null && !name.getString().isEmpty()) {
                lines.add(name.getString());
            }
        }
        return lines;
    }
}
